LoadLuaLib("all");

function ProcInit()

	print("Lua Loaded");

end