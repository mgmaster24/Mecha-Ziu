--Explosion
nNumEmitters = 1;
fLifeTime = 0.3;
fStartSizeX = 20.5;
fStartSizeY = 20.5;
fEndSizeX = 15.0;
fEndSizeY = 15.0;
nParticleAmount = 3;
nStartColorAl = 255;
nStartColorR = 255;
nStartColorG = 255;
nStartColorB = 255;
nEndColorAl = 0;
nEndColorR = 255;
nEndColorG = 200;
nEndColorB = 200;
fEmitterPosX = 0.0;
fEmitterPosY = 5.0;
fEmitterPosZ = 0.0;
bOn = 1;
bLoop = 0;
--If it will pause, this will be 1
bPause = 0;

--If there are multiple emitters this will be 1
bMultEmitters = 0;

--Default Particle
bRandX = 1;
fMinX = -0.5;
fMaxX = 0.5;
vVelocityX = 0.0;
bRandY = 0;
fMinY = -0.5;
fMaxY = 0.5;
vVelocityY = 0.0;
vVelocityZ = 0.0;

bRandom = 0;
fDecr = 0.1;
szPart = "./Assets/Particles/spikey_star_2.png";