--Explosion
nNumEmitters = 1;
fLifeTime = 1.0;
fStartSizeX = 0.0;
fStartSizeY = 0.0;
fEndSizeX = 0.5;
fEndSizeY = 0.5;
nParticleAmount = 10;
nStartColorAl = 255;
nStartColorR = 255;
nStartColorG = 255;
nStartColorB = 100;
nEndColorAl = 255;
nEndColorR = 255;
nEndColorG = 255;
nEndColorB = 50;
fEmitterPosX = 0.0;
fEmitterPosY = 0.5;
fEmitterPosZ = 0.0;
bOn = 1;
bLoop = 1;
--If it will pause, this will be 1
bPause = 0;

--If there are multiple emitters this will be 1
bMultEmitters = 0;

--Default Particle
bRandX = 1;
fMinX = -2.0;
fMaxX = 2.0;
vVelocityX = 0.0;
bRandY = 1;
fMinY = -2.0;
fMaxY = 2.0;
vVelocityY = 0.0;
vVelocityZ = 0.0;

bRandom = 0;
fDecr = 0.1;
szPart = "./Assets/Particles/blurred_star.tga";