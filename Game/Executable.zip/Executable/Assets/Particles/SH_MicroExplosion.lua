--Explosion for mines
nNumEmitters = 1;
fLifeTime = 0.3;
fStartSizeX = 0.01;
fStartSizeY = 0.01;
fEndSizeX = 0.5;
fEndSizeY = 0.5;
nParticleAmount = 20;
nStartColorAl = 255;
nStartColorR = 150;
nStartColorG = 100;
nStartColorB = 0;
nEndColorAl = 0;
nEndColorR = 150;
nEndColorG = 0;
nEndColorB = 0;
fEmitterPosX = 0.0;
fEmitterPosY = 0.0;
fEmitterPosZ = 0.0;
bOn = 1;
bLoop = 1;
--If it will pause, this will be 1
bPause = 0;

--If there are multiple emitters this will be 1
bMultEmitters = 0;

--Default Particle
bRandX = 1;
fMinX = -5.0;
fMaxX = 5.0;
vVelocityX = 0.0;
bRandY = 1;
fMinY = -5.0;
fMaxY = 5.0;
vVelocityY = 0.0;
vVelocityZ = 0.0;

bRandom = 0;
fDecr = 0.0;
szPart = "./Assets/Particles/explosion.tga";