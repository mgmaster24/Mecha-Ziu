--Explosion
nNumEmitters = 1;
fLifeTime = 2.0;
fStartSizeX = 0.0;
fStartSizeY = 0.0;
fEndSizeX = 55.0;
fEndSizeY = 55.0;
nParticleAmount = 10;
nStartColorAl = 255;
nStartColorR = 255;
nStartColorG = 200;
nStartColorB = 0;
nEndColorAl = 0;
nEndColorR = 200;
nEndColorG = 50;
nEndColorB = 0;
fEmitterPosX = 50.0;
fEmitterPosY = 0.0;
fEmitterPosZ = 0.0;
bOn = 1;
bLoop = 1;
--If it will pause, this will be 1
bPause = 0;

--If there are multiple emitters this will be 1
bMultEmitters = 0;

--Default Particle
bRandX = 0;
fMinX = -1.5;
fMaxX = 1.5;
vVelocityX = 0.0;
bRandY = 1;
fMinY = -5.0;
fMaxY = 5.0;
vVelocityY = 0.0;
vVelocityZ = -100.0;

bRandom = 0;
fDecr = 0.4;
szPart = "./Assets/Particles/firewallleft.tga";