--Explosion
nNumEmitters = 1;
fLifeTime = 4.0;
fStartSizeX = 5.0;
fStartSizeY = 5.0;
fEndSizeX = 0.0;
fEndSizeY = 0.0;
nParticleAmount = 4;
nStartColorAl = 0;
nStartColorR = 200;
nStartColorG = 200;
nStartColorB = 255;
nEndColorAl = 255;
nEndColorR = 50;
nEndColorG = 50;
nEndColorB = 160;
fEmitterPosX = 0.0;
fEmitterPosY = 0.0;
fEmitterPosZ = 0.0;
bOn = 1;
bLoop = 1;
--If it will pause, this will be 1
bPause = 0;

--If there are multiple emitters this will be 1
bMultEmitters = 0;

--Default Particle
bRandX = 0;
fMinX = -0.5;
fMaxX = 0.5;
vVelocityX = 0.0;
bRandY = 0;
fMinY = 0.0;
fMaxY = 0.5;
vVelocityY = 0.0;
vVelocityZ = 0.0;

bRandom = 0;
fDecr = 1.0;
szPart = "./Assets/Particles/spots.tga";