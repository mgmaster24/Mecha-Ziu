--Explosion
nNumEmitters = 1;
fLifeTime = 1.5;
fStartSizeX = 1.0;
fStartSizeY = 1.0;
fEndSizeX = 30.0;
fEndSizeY = 30.0;
nParticleAmount = 20;
nStartColorAl = 255;
nStartColorR = 150;
nStartColorG = 0;
nStartColorB = 0;
nEndColorAl = 0;
nEndColorR = 150;
nEndColorG = 100;
nEndColorB = 0;
fEmitterPosX = 0.0;
fEmitterPosY = 10.5;
fEmitterPosZ = -3.5;
bOn = 1;
bLoop = 0;
--If it will pause, this will be 1
bPause = 0;

--If there are multiple emitters this will be 1
bMultEmitters = 0;

--Default Particle
bRandX = 1;
fMinX = -15.0;
fMaxX = 15.0;
vVelocityX = 0.0;
bRandY = 1;
fMinY = -15.0;
fMaxY = 15.0;
vVelocityY = 0.0;
vVelocityZ = 0.0;

bRandom = 0;
fDecr = 0.0;
szPart = "./Assets/Particles/explosion.tga";