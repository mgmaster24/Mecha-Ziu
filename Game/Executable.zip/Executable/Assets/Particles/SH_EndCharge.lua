--Charge Cannon System
--Ring Emitter
nNumEmitters = 1;
fLifeTime = 4.0;
fStartSizeX = 2.0;
fStartSizeY = 2.0;
fEndSizeX = 0.0;
fEndSizeY = 0.0;
nParticleAmount = 3;
nStartColorAl = 155;
nStartColorR = 200;
nStartColorG = 200;
nStartColorB = 255;
nEndColorAl = 255;
nEndColorR = 50;
nEndColorG = 50;
nEndColorB = 160;
fEmitterPosX = 0.0;
fEmitterPosY = 0.0;
fEmitterPosZ = 0.0;
bLoop = 0;
bOn = 1;
bPause = 0;

--If there are multiple emitters this will be 1
bMultEmitters = 0;

--Default Particle
bRandX = 0;
vVelocityX = 0.0;
bRandY = 0;
vVelocityY = 0.0;
vVelocityZ = 0.0;

bRandom = 0;
fDecr = 0.0;
szPart = "./Assets/Particles/gd_puff.png";