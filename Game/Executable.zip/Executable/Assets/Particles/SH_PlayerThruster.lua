--Thruster Emitter
nNumEmitters = 1;
fLifeTime = 0.5;
fStartSizeX = 0.4;
fStartSizeY = 0.8;
fEndSizeX = 0.1;
fEndSizeY = 0.1;
nParticleAmount = 30;
nStartColorAl = 180;
nStartColorR = 11;
nStartColorG = 50;
nStartColorB = 187;
nEndColorAl = 200;
nEndColorR = 230;
nEndColorG = 220;
nEndColorB = 10;
fEmitterPosX = 0.0;
fEmitterPosY = 1.0;
fEmitterPosZ = -0.8;
bOn = 1;
bLoop = 1;
--If it will pause, this will be 1
bPause = 0;

--If there are multiple emitters this will be 1
bMultEmitters = 0;

--Default Particle
bRandX = 0;
vVelocityX = 0.0;
bRandY = 0;
vVelocityY = -0.5;
vVelocityZ = 0.0;

bRandom = 0;
fDecr = 0.08;
szPart = "./Assets/Particles/flare.png";