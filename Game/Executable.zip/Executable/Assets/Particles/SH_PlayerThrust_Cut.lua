--Thruster Emitter
nNumEmitters = 1;
fLifeTime = 0.5;
fStartSizeX = 6.7;
fStartSizeY = 6.0;
fEndSizeX = 6.3;
fEndSizeY = 6.3;
nParticleAmount = 30;
nStartColorAl = 180;
nStartColorR = 11;
nStartColorG = 50;
nStartColorB = 187;
nEndColorAl = 200;
nEndColorR = 230;
nEndColorG = 220;
nEndColorB = 10;
fEmitterPosX = 0.0;
fEmitterPosY = 0.0;
fEmitterPosZ = 0.0;
bOn = 1;
bLoop = 1;
--If it will pause, this will be 1
bPause = 0;

--If there are multiple emitters this will be 1
bMultEmitters = 0;

--Default Particle
bRandX = 0;
vVelocityX = 0;
bRandY = 0;
vVelocityY = 0;
vVelocityZ = 0;

bRandom = 0;
fDecr = 0.08;
szPart = "./Assets/Particles/flare.png";