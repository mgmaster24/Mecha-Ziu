--Explosion
nNumEmitters = 1;
fLifeTime = 1.0;
fStartSizeX = 0.1;
fStartSizeY = 0.1;
fEndSizeX = 2.0;
fEndSizeY = 2.0;
nParticleAmount = 10;
nStartColorAl = 75;
nStartColorR = 50;
nStartColorG = 50;
nStartColorB = 50;
nEndColorAl = 0;
nEndColorR = 5;
nEndColorG = 5;
nEndColorB = 5;
fEmitterPosX = 0.0;
fEmitterPosY = 0.0;
fEmitterPosZ = -1.0;
bOn = 1;
bLoop = 0;
--If it will pause, this will be 1
bPause = 0;

--If there are multiple emitters this will be 1
bMultEmitters = 0;

--Default Particle
bRandX = 1;
fMinX = -0.5;
fMaxX = 0.5;
vVelocityX = 0.0;
bRandY = 1;
fMinY = -0.5;
fMaxY = 0.5;
vVelocityY = 0.0;
vVelocityZ = 0.0;

bRandom = 0;
fDecr = 0.0;
szPart = "./Assets/Particles/smoke_puff.tga";