--Charge Cannon System
--Ring Emitter
nNumEmitters = 1;
fLifeTime = 1.0;
fStartSizeX = 0.1;
fStartSizeY = 0.1;
fEndSizeX = 1.0;
fEndSizeY = 0.5;
nParticleAmount = 10;
nStartColorAl = 255;
nStartColorR = 160;
nStartColorG = 160;
nStartColorB = 50;
nEndColorAl = 0;
nEndColorR = 200;
nEndColorG = 200;
nEndColorB = 0;
fEmitterPosX = 0.0;
fEmitterPosY = 0.0;
fEmitterPosZ = 0.5;
bLoop = 1;
bOn = 1;
bPause = 0;

--If there are multiple emitters this will be 1
bMultEmitters = 0;
szNextScript = "./Assets/Particles/SH_ChargeCenter.lua";

--Default Particle
bRandX = 0;
vVelocityX = 0.0;
bRandY = 0;
vVelocityY = 0.0;
vVelocityZ = 0.0;

bRandom = 0;
fDecr = 0.1;
szPart = "./Assets/Particles/plume.png";