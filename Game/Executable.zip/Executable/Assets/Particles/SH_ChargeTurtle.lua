--Charge Cannon System
--Ring Emitter
nNumEmitters = 1;
fLifeTime = 10.0;
fStartSizeX = 20.5;
fStartSizeY = 20.5;
fEndSizeX = 52.0;
fEndSizeY = 52.0;
nParticleAmount = 3;
nStartColorAl = 255;
nStartColorR = 160;
nStartColorG = 50;
nStartColorB = 50;
nEndColorAl = 155;
nEndColorR = 255;
nEndColorG = 200;
nEndColorB = 200;
fEmitterPosX = 0.0;
fEmitterPosY = 0.0;
fEmitterPosZ = 0.0;
bLoop = 1;
bOn = 1;
bPause = 0;

--If there are multiple emitters this will be 1
bMultEmitters = 0;

--Default Particle
bRandX = 0;
vVelocityX = 0.0;
bRandY = 0;
vVelocityY = 0.0;
vVelocityZ = 0.0;

bRandom = 0;
fDecr = 3.3;
szPart = "./Assets/Particles/gd_puff.png";